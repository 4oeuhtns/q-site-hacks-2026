def run(client, rules):
    from qduel_sdk.rules import OPEN8_RULESET
    if rules.version == OPEN8_RULESET:
        from duelkit.recovery8.open_starter import run_defender
        return run_defender(client, rules)
    if rules.qubits == 8:
        from duelkit.recovery8.adapter import run_defender
        return run_defender(client, rules)
    from duelkit.recovery4.adapter import run_defender
    # grouped=True also fits groups of interacting gates (shells), not only one gate at a time.
    return run_defender(client, rules, grouped=True)
